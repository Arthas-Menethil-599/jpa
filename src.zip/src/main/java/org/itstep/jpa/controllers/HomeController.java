package org.itstep.jpa.controllers;

import org.itstep.jpa.entities.Student;
import org.itstep.jpa.services.StudentService;
import org.itstep.jpa.services.StudentServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class HomeController {

    private final StudentService service;

    public HomeController(final StudentService service) {
        this.service = service;
    }

    @GetMapping(value = "/")
    public String index(Model model) {
        List<Student> students = service.getAllStudent();
        model.addAttribute("student", new Student());
        model.addAttribute("students", students);
        return "index";
    }

    @PostMapping(value = "/add-student")
    public String index(@ModelAttribute Student student) {
        service.addStudent(student);
        return "redirect:/";
    }

    @GetMapping(value="/search/{id}")
    public String searchStudent(@PathVariable("id") Long id, Model model) {
        Student student = service.getStudent(id);
        model.addAttribute("student", student);
        return "student";
    }

    @DeleteMapping(value="/delete/{id}")
    public String deleteStudent(@PathVariable("id") Long id) {
        service.deleteStudent(id);
        return "redirect:/";
    }

}
